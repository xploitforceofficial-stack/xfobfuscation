
import React, { useState, useEffect, useRef } from 'react';
import { 
  Terminal, 
  Lock, 
  ChevronRight,
  Clipboard,
  Download,
  AlertTriangle,
  Code,
  Zap,
  Activity,
  Cpu,
  Trash2,
  Settings,
  History,
  Info,
  Layers,
  CheckCircle2,
  Monitor
} from 'lucide-react';
import CodeEditor from './components/CodeEditor';
import { obfuscateLuau } from './services/obfuscatorService';
import { VERSION, APP_NAME } from './constants';

type Tab = 'editor' | 'config' | 'archives' | 'intel';

interface ArchiveEntry {
  id: string;
  timestamp: string;
  sourcePreview: string;
  payload: string;
}

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<Tab>('editor');
  const [sourceCode, setSourceCode] = useState<string>('--// XF OMEGA CORE\nfunction main()\n    local secret = 0xDEADBEEF\n    print("initialized system with entropy: " .. secret)\nend\nmain()');
  const [obfCode, setObfCode] = useState<string>('');
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [logs, setLogs] = useState<string[]>([]);
  const [intensity, setIntensity] = useState<'Standard' | 'Maximum' | 'Void'>('Maximum');
  const [archives, setArchives] = useState<ArchiveEntry[]>([]);
  const logRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const saved = localStorage.getItem('xf_archives');
    if (saved) setArchives(JSON.parse(saved));
  }, []);

  useEffect(() => {
    if (logRef.current) logRef.current.scrollTop = logRef.current.scrollHeight;
  }, [logs]);

  const addLog = (msg: string) => {
    setLogs(prev => [...prev, `[+] ${msg}`]);
  };

  /**
   * Clears the current session data.
   */
  const handleReset = () => {
    setSourceCode('');
    setObfCode('');
    setLogs([]);
  };

  const handleTransform = async () => {
    if (!sourceCode.trim() || isProcessing) return;
    setIsProcessing(true);
    setLogs([]);
    
    const sequence = [
      { t: 'initializing transformation pipeline', d: 100 },
      { t: `intensity set to ${intensity.toUpperCase()}`, d: 150 },
      { t: 'parsing source AST literals', d: 200 },
      { t: 'generating bit-shredding layers', d: 300 },
      { t: 'flattening execution flow states', d: 250 },
      { t: 'injecting polymorphic math junk', d: 400 },
      { t: 'finalizing payload structure', d: 100 }
    ];

    for (const step of sequence) {
      addLog(step.t);
      await new Promise(r => setTimeout(r, step.d));
    }

    try {
      const result = obfuscateLuau(sourceCode);
      setObfCode(result);
      
      const newArchive: ArchiveEntry = {
        id: Math.random().toString(36).substr(2, 9).toUpperCase(),
        timestamp: new Date().toLocaleTimeString(),
        sourcePreview: sourceCode.substring(0, 30) + '...',
        payload: result
      };
      
      const updatedArchives = [newArchive, ...archives].slice(0, 10);
      setArchives(updatedArchives);
      localStorage.setItem('xf_archives', JSON.stringify(updatedArchives));
      
      addLog('transformation sequence successful');
    } catch (e) {
      addLog('fatal: memory allocation overflow');
    } finally {
      setIsProcessing(false);
    }
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case 'editor':
        return (
          <div className="flex-1 flex flex-col gap-6 overflow-hidden">
            {/* Input Area */}
            <div className="flex-1 min-h-0 border border-purple-900/10 bg-[#0f0f11]/60 backdrop-blur-md flex flex-col overflow-hidden rounded-xl shadow-2xl transition-all duration-500 hover:border-purple-900/20">
              <div className="h-10 border-b border-[#1e293b]/30 flex items-center px-4 justify-between bg-black/40">
                <div className="flex items-center gap-3">
                  <Code size={12} className="text-purple-500" />
                  <span className="text-[9px] uppercase font-bold text-gray-400 tracking-widest">Target_Source</span>
                </div>
                <span className="text-[9px] text-gray-600 font-bold uppercase tracking-tighter">Luau/Lua 5.1</span>
              </div>
              <div className="flex-1 min-h-0">
                <CodeEditor label="input" value={sourceCode} onChange={setSourceCode} />
              </div>
            </div>

            {/* Output Panel */}
            <div className="flex-1 min-h-0 border border-red-900/10 bg-[#0f0f11]/60 backdrop-blur-md flex flex-col overflow-hidden rounded-xl shadow-2xl transition-all duration-500 hover:border-red-900/20">
              <div className="h-10 border-b border-[#1e293b]/30 flex items-center px-4 justify-between bg-black/40">
                <div className="flex items-center gap-3">
                  <Lock size={12} className="text-red-600" />
                  <span className="text-[9px] uppercase font-bold text-gray-400 tracking-widest">OMEGA_Payload</span>
                </div>
                <div className="flex items-center gap-4">
                  {obfCode && (
                    <div className="flex gap-2">
                      <button onClick={() => navigator.clipboard.writeText(obfCode)} className="p-1.5 hover:bg-white/5 text-gray-500 hover:text-white rounded transition-all">
                        <Clipboard size={14} />
                      </button>
                      <button className="p-1.5 hover:bg-white/5 text-gray-500 hover:text-white rounded transition-all">
                        <Download size={14} />
                      </button>
                    </div>
                  )}
                </div>
              </div>
              <div className="flex-1 min-h-0 opacity-80 group">
                <CodeEditor label="output" value={obfCode} readOnly placeholder="--- waiting for shredder initialize ---" />
              </div>
            </div>
          </div>
        );
      case 'config':
        return (
          <div className="flex-1 p-8 space-y-8 overflow-y-auto scrollbar-hide">
            <div className="max-w-2xl space-y-8">
              <div className="space-y-4">
                <h3 className="text-xs font-bold text-white uppercase tracking-widest flex items-center gap-3">
                  <Layers size={14} className="text-purple-500" /> Entropy Configuration
                </h3>
                <div className="grid grid-cols-3 gap-4">
                  {(['Standard', 'Maximum', 'Void'] as const).map(lvl => (
                    <button 
                      key={lvl}
                      onClick={() => setIntensity(lvl)}
                      className={`p-4 rounded-xl border transition-all text-left space-y-2 ${intensity === lvl ? 'bg-purple-600/10 border-purple-500/50 shadow-[0_0_20px_rgba(168,85,247,0.1)]' : 'bg-white/5 border-white/10 hover:border-white/20'}`}
                    >
                      <div className={`text-[10px] font-bold uppercase tracking-widest ${intensity === lvl ? 'text-purple-400' : 'text-gray-500'}`}>{lvl}</div>
                      <div className="text-[9px] text-gray-600 leading-relaxed font-medium">
                        {lvl === 'Standard' && 'Balanced performance. 1:4 expansion ratio.'}
                        {lvl === 'Maximum' && 'Standard VM-protection. 1:12 expansion ratio.'}
                        {lvl === 'Void' && 'Extreme entropy. Recursive bit-shredding enabled.'}
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-4">
                <h3 className="text-xs font-bold text-white uppercase tracking-widest flex items-center gap-3">
                  <Settings size={14} className="text-purple-500" /> Toggles
                </h3>
                <div className="space-y-3">
                  {[
                    { n: 'Runtime Mutation', d: 'Change instruction keys during execution' },
                    { n: 'Anti-Beautifier', d: 'Inject symbols that break indentation tools' },
                    { n: 'Memory Poisoning', d: 'Corrupt script data after initial load' }
                  ].map(opt => (
                    <div key={opt.n} className="flex items-center justify-between p-4 bg-white/5 border border-white/5 rounded-xl">
                      <div>
                        <div className="text-[10px] font-bold text-gray-300 uppercase tracking-widest">{opt.n}</div>
                        <div className="text-[9px] text-gray-600">{opt.d}</div>
                      </div>
                      <div className="w-8 h-4 bg-purple-600/20 border border-purple-500/20 rounded-full flex items-center px-1">
                        <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        );
      case 'archives':
        return (
          <div className="flex-1 p-8 space-y-6 overflow-y-auto scrollbar-hide">
            <h3 className="text-xs font-bold text-white uppercase tracking-widest flex items-center gap-3">
              <History size={14} className="text-purple-500" /> Previous Builds
            </h3>
            {archives.length === 0 ? (
              <div className="h-64 flex flex-col items-center justify-center border border-dashed border-white/10 rounded-2xl opacity-20">
                <History size={32} className="mb-4" />
                <span className="text-[10px] uppercase font-bold tracking-widest">No builds detected</span>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {archives.map(a => (
                  <div key={a.id} className="p-4 bg-white/5 border border-white/10 rounded-xl hover:border-purple-500/30 transition-all group">
                    <div className="flex justify-between items-start mb-3">
                      <div>
                        <div className="text-[10px] font-bold text-white tracking-widest">BUILD_{a.id}</div>
                        <div className="text-[8px] text-gray-600 uppercase font-bold">{a.timestamp}</div>
                      </div>
                      <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                         <button onClick={() => navigator.clipboard.writeText(a.payload)} className="p-1 hover:text-white transition-colors"><Clipboard size={12}/></button>
                      </div>
                    </div>
                    <div className="bg-black/40 p-2 rounded font-mono text-[9px] text-gray-600 truncate">
                      {a.sourcePreview}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        );
      case 'intel':
        return ( activeTab === 'intel' &&
          <div className="flex-1 p-8 overflow-y-auto scrollbar-hide">
             <div className="max-w-3xl space-y-12">
                <section className="space-y-4">
                  <h2 className="text-sm font-black text-white uppercase tracking-[0.2em] border-b border-white/5 pb-4">XF Technical Specifications</h2>
                  <p className="text-[11px] text-gray-500 leading-relaxed font-medium">
                    The XF transformation engine utilizes a custom bit-shredding algorithm designed to fragment high-level logic into atomized instructions. 
                    These instructions are housed within a non-linear execution table, preventing standard static analysis and dumper tools from reconstructing the original source code.
                  </p>
                </section>
                <div className="grid grid-cols-2 gap-8">
                  <div className="space-y-4">
                    <h3 className="text-[10px] font-bold text-purple-400 uppercase tracking-widest">Protection Matrix</h3>
                    <ul className="space-y-3 text-[10px] font-bold text-gray-600">
                      <li className="flex items-center gap-3"><CheckCircle2 size={12} className="text-purple-900" /> Control-Flow Flattening</li>
                      <li className="flex items-center gap-3"><CheckCircle2 size={12} className="text-purple-900" /> Variable Shredding</li>
                      <li className="flex items-center gap-3"><CheckCircle2 size={12} className="text-purple-900" /> Anti-Dumper Hooks</li>
                      <li className="flex items-center gap-3"><CheckCircle2 size={12} className="text-purple-900" /> Opcodes Scrambling</li>
                    </ul>
                  </div>
                  <div className="p-6 bg-purple-950/5 border border-purple-900/10 rounded-2xl flex flex-col justify-center items-center text-center">
                    <Monitor size={32} className="text-purple-900 mb-4" />
                    <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Core Status: Stable</span>
                  </div>
                </div>
             </div>
          </div>
        );
    }
  };

  return ( activeTab &&
    <div className="relative flex h-screen w-full bg-[#080809] text-[#94a3b8] font-mono p-4 gap-4 overflow-hidden z-10 selection:bg-purple-500/30">
      
      {/* Professional Sidebar Navigation */}
      <div className="w-16 flex flex-col gap-8 border border-white/[0.03] bg-black/40 backdrop-blur-xl items-center py-8 rounded-2xl shadow-2xl">
        <div className="relative group cursor-pointer mb-6">
          <div className="absolute inset-0 bg-purple-600 blur-2xl opacity-0 group-hover:opacity-20 transition-all duration-700"></div>
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-600/10 to-transparent flex items-center justify-center border border-purple-500/20 transition-transform active:scale-90">
            <Zap size={18} className="text-purple-500" fill="currentColor" />
          </div>
        </div>
        
        <nav className="flex flex-col gap-8">
          <button onClick={() => setActiveTab('editor')} className={`p-2 transition-all rounded-lg ${activeTab === 'editor' ? 'text-white bg-white/5 border border-white/10 shadow-lg' : 'text-gray-700 hover:text-gray-400'}`}>
            <Cpu size={20} strokeWidth={activeTab === 'editor' ? 2.5 : 1.5} />
          </button>
          <button onClick={() => setActiveTab('config')} className={`p-2 transition-all rounded-lg ${activeTab === 'config' ? 'text-white bg-white/5 border border-white/10 shadow-lg' : 'text-gray-700 hover:text-gray-400'}`}>
            <Settings size={20} strokeWidth={activeTab === 'config' ? 2.5 : 1.5} />
          </button>
          <button onClick={() => setActiveTab('archives')} className={`p-2 transition-all rounded-lg ${activeTab === 'archives' ? 'text-white bg-white/5 border border-white/10 shadow-lg' : 'text-gray-700 hover:text-gray-400'}`}>
            <History size={20} strokeWidth={activeTab === 'archives' ? 2.5 : 1.5} />
          </button>
          <button onClick={() => setActiveTab('intel')} className={`p-2 transition-all rounded-lg ${activeTab === 'intel' ? 'text-white bg-white/5 border border-white/10 shadow-lg' : 'text-gray-700 hover:text-gray-400'}`}>
            <Info size={20} strokeWidth={activeTab === 'intel' ? 2.5 : 1.5} />
          </button>
        </nav>

        <button onClick={() => { handleReset(); addLog('buffers cleared'); }} className="p-2 text-gray-800 hover:text-red-900 transition-colors mt-auto mb-2">
          <Trash2 size={18} />
        </button>
      </div>

      {/* Primary Workspace */}
      <div className="flex-1 flex flex-col gap-4 min-w-0">
        
        {/* Workspace Header */}
        <header className="h-14 flex items-center justify-between px-4 bg-black/20 rounded-xl border border-white/[0.03] backdrop-blur-md">
          <div className="flex flex-col">
            <h1 className="text-[11px] font-black text-white uppercase tracking-[0.4em] flex items-center gap-3">
              <span className="w-1.5 h-1.5 bg-purple-600 rounded-full animate-ping"></span>
              {APP_NAME} <span className="text-gray-800 font-thin lowercase">/</span> <span className="text-gray-500 font-bold tracking-widest">{activeTab}</span>
            </h1>
          </div>
          <div className="flex items-center gap-8">
             <div className="flex flex-col items-end">
                <span className="text-[8px] text-gray-700 uppercase font-black tracking-widest">Kernel_State</span>
                <span className="text-[10px] text-purple-600 font-black tracking-tighter">SECURE_LINK_ESTABLISHED</span>
             </div>
             <button 
                onClick={handleTransform}
                disabled={isProcessing || !sourceCode.trim()}
                className="bg-white hover:bg-gray-200 text-black h-9 px-6 rounded-lg text-[9px] font-black uppercase tracking-[0.2em] transition-all active:scale-95 disabled:opacity-20 flex items-center gap-3 shadow-[0_0_20px_rgba(255,255,255,0.05)]"
             >
                {isProcessing ? <RefreshCcw size={12} className="animate-spin" /> : <Zap size={12} fill="black" />}
                {isProcessing ? 'SHREDDING' : 'TRANSFORM'}
             </button>
          </div>
        </header>

        {/* Dynamic Content */}
        {renderTabContent()}

        {/* Global Warning Bar */}
        <footer className="h-12 bg-red-950/5 border border-red-900/10 rounded-xl px-6 flex items-center gap-4">
          <AlertTriangle size={12} className="text-red-900 animate-pulse" />
          <p className="text-[9px] font-bold text-red-900 uppercase tracking-widest">
            warning: analysis or modification of binary output may result in runtime instability or hardware de-sync.
          </p>
        </footer>
      </div>

      {/* Telemetry Column */}
      <div className="w-80 flex flex-col gap-4 shrink-0">
        
        {/* Technical Logs */}
        <div className="flex-1 flex flex-col border border-white/[0.03] bg-black/40 backdrop-blur-md rounded-2xl overflow-hidden shadow-2xl">
          <div className="h-12 border-b border-[#1e293b]/20 flex items-center px-4 bg-black/20">
            <Terminal size={12} className="text-gray-600 mr-3" />
            <span className="text-[9px] text-gray-500 uppercase font-black tracking-widest">Telemetry</span>
            <div className="ml-auto w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
          </div>
          <div ref={logRef} className="flex-1 p-5 overflow-y-auto font-mono text-[9px] leading-relaxed space-y-2 scrollbar-hide select-none opacity-50">
            {logs.length === 0 && <span className="italic text-gray-800 tracking-widest uppercase">system_idle...</span>}
            {logs.map((log, i) => (
              <div key={i} className="flex gap-4 group">
                <span className="text-purple-900/40 shrink-0">{i.toString().padStart(2, '0')}</span>
                <span className="text-gray-500 group-hover:text-gray-400 transition-colors">{log}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Diagnostic Panel */}
        <div className="h-48 border border-white/[0.03] bg-black/40 backdrop-blur-md rounded-2xl p-6 flex flex-col justify-between shadow-2xl">
          <div className="space-y-4">
             <div className="flex justify-between items-center">
                <span className="text-[8px] text-gray-700 uppercase font-black tracking-widest">Entropy_Ratio</span>
                <span className="text-[10px] text-purple-600 font-black tracking-tighter">0.9997</span>
             </div>
             <div className="w-full h-1 bg-white/[0.02] rounded-full overflow-hidden">
                <div className="h-full w-[95%] bg-purple-600 shadow-[0_0_10px_rgba(168,85,247,0.5)]"></div>
             </div>
             <div className="flex justify-between items-center">
                <span className="text-[8px] text-gray-700 uppercase font-black tracking-widest">Memory_Pool</span>
                <span className="text-[10px] text-emerald-600 font-black tracking-tighter">ALLOCATED</span>
             </div>
          </div>
          <div className="text-[9px] font-black text-gray-800 uppercase tracking-widest border-t border-white/[0.03] pt-4 flex justify-between items-center">
            build_{VERSION} <ChevronRight size={10} className="text-purple-900" />
          </div>
        </div>
      </div>
    </div>
  );
};

const RefreshCcw = ({ size, className }: { size: number, className: string }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M21 12a9 9 0 0 0-9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/><path d="M3 12a9 9 0 0 0 9 9 9.75 9.75 0 0 0 6.74-2.74L21 16"/><path d="M16 16h5v5"/>
  </svg>
);

export default App;
