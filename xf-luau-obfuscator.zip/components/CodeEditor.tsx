
import React from 'react';

interface CodeEditorProps {
  value: string;
  onChange?: (val: string) => void;
  readOnly?: boolean;
  placeholder?: string;
  label: string;
}

const CodeEditor: React.FC<CodeEditorProps> = ({ value, onChange, readOnly, placeholder, label }) => {
  return (
    <div className="flex h-full w-full bg-transparent">
      <div className="relative flex-1 flex overflow-hidden">
        {/* Professional Technical Gutter */}
        <div className="w-10 py-5 bg-black/20 flex flex-col items-center border-r border-white/[0.05] select-none shrink-0 overflow-hidden">
           {[...Array(500)].map((_, i) => (
             <span key={i} className={`text-[8px] font-mono leading-[1.6rem] font-black transition-opacity ${value.split('\n').length > i ? 'text-gray-700 opacity-100' : 'text-gray-900 opacity-20'}`}>
               {(i + 1).toString().padStart(2, '0')}
             </span>
           ))}
        </div>
        
        <textarea
          value={value}
          onChange={(e) => onChange?.(e.target.value)}
          readOnly={readOnly}
          placeholder={placeholder}
          className={`
            flex-1 p-5 bg-transparent font-mono text-[11px] leading-[1.6rem] resize-none outline-none 
            text-gray-500 placeholder:text-gray-800 caret-purple-600 selection:bg-purple-600/20
            scrollbar-hide font-medium
            ${readOnly ? 'cursor-default select-all' : 'cursor-text'}
          `}
          spellCheck={false}
        />
      </div>
    </div>
  );
};

export default CodeEditor;
