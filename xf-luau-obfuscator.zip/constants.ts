
export const COLORS = {
  primary: '#f8fafc', // Slate 50
  secondary: '#020617', // Slate 950
  background: '#0a0a0b',
  surface: '#0f0f11',
  text: '#94a3b8', // Slate 400
  accent: '#334155', // Slate 700
};

export const APP_NAME = "XF OBFUSCATION";
export const VERSION = "build01_stable";
