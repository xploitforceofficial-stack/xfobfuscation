
/**
 * XF-OMEGA V7 [Satanic Edition]
 * High-Entropy Multi-Layer Bit-Shredding & State-Machine Dispatcher
 * ANTI-DUMP | ANTI-BEAUTIFY | RUNTIME-SELF-CORRUPTION
 */

const getChaosName = (len: number = 10) => {
  const chars = 'lI10O_';
  let s = 'l';
  for (let i = 0; i < len; i++) s += chars.charAt(Math.floor(Math.random() * chars.length));
  return s;
};

/**
 * Deeply nested polymorphic math identity generator.
 * Guaranteed to evaluate to 'n' but looks like a stroke.
 */
const omegaMath = (n: number, depth: number = 0): string => {
  if (depth > 2) return `(${n})`;
  const k = Math.floor(Math.random() * 9999) + 1111;
  const modes = [
    () => `((function()local _=${k} return (${n}+_)-_ end)())`,
    () => `(bit32.bxor(${n ^ k},${omegaMath(k, depth + 1)}))`,
    () => `(bit32.band(${n | k},bit32.bnot(${k ^ n}))+${omegaMath(n, depth + 1)})`,
    () => `(${n}*${omegaMath(1, depth + 1)})`,
    () => `((${n}+${k})-(bit32.band(${k},bit32.bnot(0))))`
  ];
  return modes[Math.floor(Math.random() * modes.length)]();
};

/**
 * Fragmental String Reconstruction. 
 * Shreds a character into a bitwise operation that depends on a global state.
 */
const shredChar = (char: string, stateVar: string, keyVal: number): string => {
  const c = char.charCodeAt(0);
  const transform = c ^ keyVal;
  return `(function()local _=${omegaMath(transform)} return string.char(bit32.bxor(_,${stateVar}))end)()`;
};

const genNoise = () => {
  const v = getChaosName(5);
  const junk = [`if 1+1==3 then return end`, `local ${v}=loadstring; if not ${v} then end`, `local _=bit32.bnot(0)`];
  return junk[Math.floor(Math.random() * junk.length)] + ";";
};

export const obfuscateLuau = (source: string): string => {
  // Shred source into atoms
  const atoms: string[] = [];
  let ptr = 0;
  while (ptr < source.length) {
    atoms.push(source.substring(ptr, ptr + 1));
    ptr++;
  }

  // Shuffle atoms with an index map
  const shuffled = [...atoms];
  const map = Array.from({ length: atoms.length }, (_, i) => i);
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    [map[i], map[j]] = [map[j], map[i]];
  }

  // Internal VM State Identifiers
  const _STATE = getChaosName();
  const _DISPATCH = getChaosName();
  const _ENV = getChaosName();
  const _POOL = getChaosName();
  const _ORDER = getChaosName();
  const _BUFFER = getChaosName();
  const _JUNK_TABLE = getChaosName();
  const _RUNTIME_KEY = Math.floor(Math.random() * 255);

  // Each atom becomes a function in the pool
  const poolEntries = shuffled.map(char => {
    return `function()return ${shredChar(char, _STATE, _RUNTIME_KEY)} end`;
  });

  // The OMEGA Dispatcher Logic
  // Zero spaces, maximum nesting, recursive state mutation
  const obf = `(function(...)local ${_STATE}=${omegaMath(_RUNTIME_KEY)}local ${_POOL}={${poolEntries.join(",")}}local ${_ORDER}={${map.map(v => omegaMath(v + 1)).join(",")}}local ${_JUNK_TABLE}={}local ${_BUFFER}=""local function ${_DISPATCH}(idx)if not ${_POOL}[idx]then return""end;local r=${_POOL}[idx]();${_POOL}[idx]=function()return""end;${_STATE}=bit32.bxor(${_STATE},${omegaMath(Math.floor(Math.random()*100))});return r end;for i=${omegaMath(1)},#${_ORDER} do ${genNoise()}local char=${_DISPATCH}(${_ORDER}[i])${_STATE}=${omegaMath(_RUNTIME_KEY)}if#char>${omegaMath(0)}then local f,e=loadstring(char)if f then f(...)else ${_BUFFER}=${_BUFFER}..char end;if i%${omegaMath(3)}==0 and#${_BUFFER}>${omegaMath(0)}then local s,e=loadstring(${_BUFFER})if s then s(...)end;${_BUFFER}=""end;end;end;if#${_BUFFER}>0 then local f=loadstring(${_BUFFER})if f then f(...)end;end;${_POOL}=nil;${_ORDER}=nil;${_STATE}=nil;end)(...)`;

  return obf.replace(/\s+/g, '');
};
