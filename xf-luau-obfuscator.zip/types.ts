
export interface ObfuscationStats {
  globalCounter: number;
}

export interface ObfuscationConfig {
  name: string;
  source: string;
}

export interface ObfuscatedResult {
  code: string;
  fileName: string;
  timestamp: number;
}
